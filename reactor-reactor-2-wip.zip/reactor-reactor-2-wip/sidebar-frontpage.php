<?php
/**
 * The sidebar template containing the front page widget area
 *
 * @package Reactor
 * @subpackge Templates
 * @since 1.0.0
 */
?>

	<?php // get the front page layout
	wp_reset_postdata();
    $layout =  reactor_option('', '1c', '_template_layout'); ?>

    <?php // if front page has one sidebar and the sidebar is active
    if ( is_active_sidebar('sidebar-frontpage') && '1c' != $layout ) : ?>

        <div id="sidebar-frontpage" class="sidebar <?php reactor_columns( '', array('sidebar' => true, 'sidebar_id' => 1) ); ?>" role="complementary">
            <?php dynamic_sidebar('sidebar-frontpage'); ?>
        </div><!-- #sidebar-frontpage -->

    <?php // else show an alert
    else : if ( '1c' != $layout ) : ?>

        <div id="sidebar-frontpage" class="sidebar <?php reactor_columns( '', array('sidebar' => true, 'sidebar_id' => 1) ); ?>" role="complementary">
            <div class="alert-box secondary"><p>Add some widgets to this area!</p></div>
        </div><!-- #sidebar -->

    <?php endif; endif; ?>

    <?php // if front page has two sidebars and second sidear is active
    if ( is_active_sidebar('sidebar-frontpage-2') && ( '3c-l' == $layout || '3c-r' == $layout || '3c-c' == $layout ) ) : ?>

        <div id="sidebar-frontpage-2" class="sidebar <?php reactor_columns( '', array('sidebar' => true, 'sidebar_id' => 2) ); ?>" role="complementary">
            <?php dynamic_sidebar('sidebar-frontpage-2'); ?>
        </div><!-- #sidebar-frontpage-2 -->

    <?php // else show an alert
    else : if ( '3c-l' == $layout || '3c-r' == $layout || '3c-c' == $layout ) : ?>

        <div id="sidebar-frontpage-2" class="sidebar <?php reactor_columns( '', array('sidebar' => true, 'sidebar_id' => 2) ); ?>" role="complementary">
            <div class="alert-box secondary"><p>Add some widgets to this area!</p></div>
        </div><!-- #sidebar-2 -->

    <?php endif; endif; ?>