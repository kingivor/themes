empty-core
==========

A starter child theme for Reactor